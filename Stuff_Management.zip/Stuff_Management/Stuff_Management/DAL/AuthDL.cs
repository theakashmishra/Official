﻿using MySql.Data.MySqlClient;
using Stuff_Management.Model;
using System.Data.Common;

namespace Stuff_Management.DAL
{
    public class AuthDL : IAuthDL
    {
        public readonly IConfiguration _configuration;
        public readonly MySqlConnection _mysqlConnection;
        public AuthDL(IConfiguration configuration)
        {
            _configuration = configuration;
            _mysqlConnection = new MySqlConnection(_configuration["ConnectionStrings : MySqlDBConnection"]);

        }

        public Task<SignInResponse> SignIn(SignInRequest request)
        {
            throw new NotImplementedException();
        }

        public async Task<SignUpResponse> SignUp(SignUpRequest request)
        {
            SignUpResponse response = new SignUpResponse();
            response.IsSuccess = true;
            response.Message = "Successfull";
            try
            {
                if(!request.Password.Equals(request.ConfirmPassword))
                {
                    response.IsSuccess = false;
                    response.Message = "Password and confirm password not match.";
                    return response;
                }
                if(_mysqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _mysqlConnection.OpenAsync();
                }

                string SqlQuery = @"insert into USER_DETAILS(UserName,Password) Values (@UserName, @Password);";

                using(MySqlCommand sqlCommand = new MySqlCommand(SqlQuery, _mysqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue(parameterName: "@UserName", request.UserName);
                    sqlCommand.Parameters.AddWithValue(parameterName: "@Password", request.Password);
                    int Status =await sqlCommand.ExecuteNonQueryAsync();
                    using(DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.Message = "Login Successfull";
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.Message = "Login Failed";
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false; 
                response.Message = ex.Message;

            }
            finally
            {
                await _mysqlConnection.CloseAsync();
                await _mysqlConnection.DisposeAsync();
            }
            return response;
        }
    }
}
    