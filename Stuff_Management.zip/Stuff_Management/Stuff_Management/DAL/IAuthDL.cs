﻿using Stuff_Management.Model;

namespace Stuff_Management.DAL
{
    public interface IAuthDL
    {
        public Task<SignUpResponse> SignUp(SignUpRequest request);  
        public Task<SignInResponse> SignIn(SignInRequest request);
    }
}
